from abc import ABC


class JobConfigException(Exception):
    pass

# TODO: Base class for every job
# What can be done here:
# - Generic logging for all jobs
# -


class BaseJob(ABC):
    pass