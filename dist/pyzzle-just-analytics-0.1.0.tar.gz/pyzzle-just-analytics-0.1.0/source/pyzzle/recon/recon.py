
class BaseReconJob()